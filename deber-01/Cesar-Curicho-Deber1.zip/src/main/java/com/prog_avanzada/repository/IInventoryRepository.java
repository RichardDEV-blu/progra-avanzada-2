package com.prog_avanzada.repository;

import com.prog_avanzada.model.Inventory;

public interface IInventoryRepository extends RepositoryModel<Inventory, String>{
}

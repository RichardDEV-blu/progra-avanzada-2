package com.prog_avanzada.repository;

import com.prog_avanzada.model.PurchaseOrder;

public interface IPurchaseOrderRepository extends RepositoryModel<PurchaseOrder, Long>{
}

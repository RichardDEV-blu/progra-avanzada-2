package com.prog_avanzada.repository;

import com.prog_avanzada.model.Book;

public interface IBookRepository extends RepositoryModel<Book, String>{
}

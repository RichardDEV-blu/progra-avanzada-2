package com.prog_avanzada.repository;

import com.prog_avanzada.model.Author;

public interface IAuthorRepository extends RepositoryModel<Author, Long> {
}
